x-terminal-emulator -e 'bash -c "java -jar /home/wanghao/Desktop/solveSokoban/solve.jar;read -s -n 1 -p \"Press any key to continue...\""'
