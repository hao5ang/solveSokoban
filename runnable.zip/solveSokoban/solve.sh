java -jar solve.jar
read -s -n 1 -p "Press any key to continue..."